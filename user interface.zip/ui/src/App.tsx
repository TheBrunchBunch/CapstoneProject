import { useState } from 'react'
import './App.css'

interface PartData {
  tool: string
  method: string
  target: string
  source: string
}

function App() {
  const [activeTab, setActiveTab] = useState('parts')
  const references = [
    {
      title: "A New Model to Select Fasteners in Design for Disassembly",
      url: "https://www.sciencedirect.com/science/article/pii/S2212827116000998"
    },
    {
      title: "Automated generation and execution of disassembly actions",
      url: "https://www.sciencedirect.com/science/article/abs/pii/S0736584520302672"
    },
    {
      title: "Automatic Screw Detection and Tool Recommendation System for Robotic Disassembly",
      url: "https://asmedigitalcollection.asme.org/manufacturingscience/article/145/3/031008/1148469/Automatic-Screw-Detection-and-Tool-Recommendation"
    }
  ]
  const [searchTerm, setSearchTerm] = useState('')
  const [searchResult, setSearchResult] = useState<PartData | null>(null)
  const [allResults, setAllResults] = useState<PartData[]>([])
  const [prompt, setPrompt] = useState('')
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string }>>([])

  const partsData: PartData[] = [
    {
      tool: "Dremel",
      method: "Remove Screw",
      target: "Evap Fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Wet vac",
      method: "Empty",
      target: "Water",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Crane",
      method: "Lift or move",
      target: "Compressor",
      source: "https://screwcompressorsspecialist.com/"
    },
    {
      tool: "Forklift",
      method: "Pick up",
      target: "Compressor",
      source: "https://screwcompressorsspecialist.com/"
    },
    {
      tool: "Dremel",
      method: "remove screw",
      target: "evap fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Air",
      method: "hammer",
      target: "powered punch \u2013 Punches \u2013 [Fuel Injector]",
      source: "https://miltonindustries.com/products/power-stroke-powerpac-ford-67-bolt-repair-fuel-injector-puller-combo-xsz7k"
    },
    {
      tool: "Air",
      method: "hammer",
      target: "powered punch \u2013 Strikes \u2013 Fuel Injector",
      source: "https://miltonindustries.com/products/power-stroke-powerpac-ford-67-bolt-repair-fuel-injector-puller-combo-xsz7k"
    },
    {
      tool: "Socket",
      method: "[ROCKING]",
      target: "Nut/Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "6",
      method: "point wrench",
      target: "Tightening, Loosening \u2013 Nut/Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Socket",
      method: "Tightening, Loosening",
      target: "Nut/Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Socket/wrench",
      method: "rock in and out",
      target: "binding force",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Socket/wrench with Breaker Bar",
      method: "use leverage to remove",
      target: "stubborn bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Screw",
      method: "Tighten",
      target: "Nut",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut splitter",
      method: "Slip",
      target: "Nut",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut splitter",
      method: "Tighten",
      target: "Wedge",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut splitter",
      method: "Crank",
      target: "Nut",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut splitter",
      method: "Back off",
      target: "\u2013",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Angle grinder",
      method: "CUT HEAD OFF",
      target: "BOLT",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Angle grinder",
      method: "GRIND NUT AND BOLT",
      target: "NUT",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut splitter",
      method: "PULL OUT",
      target: "NUT",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Dremel",
      method: "Remove screw",
      target: "Back panel",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "tool",
      method: "DISASSEMBLE",
      target: "DRYER",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "tool",
      method: "OHM",
      target: "CONTROL BOARD",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Spanner wrench",
      method: "Remove nut",
      target: "Threaded antenna shaft",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Pliers",
      method: "Twist counter",
      target: "clockwise \u2013 Silver nut",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Small flat",
      method: "head screwdriver",
      target: "Pry bottom chassis out \u2013 Plastic housing",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Safety device",
      method: "deflected",
      target: "ejection",
      source: "https://woodcousa.com/disassembly-break-out-of-made-up-flanges/"
    },
    {
      tool: "Duct tape",
      method: "wrapped",
      target: "gap",
      source: "https://woodcousa.com/disassembly-break-out-of-made-up-flanges/"
    },
    {
      tool: "Dremel",
      method: "remove screw",
      target: "evap fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Pliers",
      method: "Pull",
      target: "Cotter Pin",
      source: "https://blog.mfsupply.com/category/pins/hair-pin-clip/"
    },
    {
      tool: "Hammer",
      method: "Strikes",
      target: "Projection",
      source: "https://www.premiumparts.com/blog/an-ultimate-guide-to-rivet-their-types-and-applications"
    },
    {
      tool: "Hammer",
      method: "Forms the end",
      target: "Shank",
      source: "https://www.premiumparts.com/blog/an-ultimate-guide-to-rivet-their-types-and-applications"
    },
    {
      tool: "Screwdriver",
      method: "Unscrew",
      target: "Bluetooth and wifi aerials",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Screwdriver",
      method: "Unscrew",
      target: "Driver bits",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Screwdriver",
      method: "Buy/SOURCE TOOLS",
      target: "Torx drivers",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Heat gun",
      method: "heat",
      target: "adhesive",
      source: "https://www.gluegun.com/blogs/news/industrial-glue-removal-101-tips-tricks-more"
    },
    {
      tool: "Hair dryer",
      method: "heat",
      target: "adhesive",
      source: "https://www.gluegun.com/blogs/news/industrial-glue-removal-101-tips-tricks-more"
    },
    {
      tool: "Putty knife",
      method: "scrape",
      target: "adhesive",
      source: "https://www.gluegun.com/blogs/news/industrial-glue-removal-101-tips-tricks-more"
    },
    {
      tool: "1000# sandpaper",
      method: "removal",
      target: "burr",
      source: "https://cjme.springeropen.com/articles/10.1186/s10033-023-00885-7"
    },
    {
      tool: "Hydraulic press",
      method: "Force shaft into hole",
      target: "",
      source: "https://at-machining.com/tolerance-press-fit/"
    },
    {
      tool: "Drill",
      method: "Cut the hole with threads for the final screw",
      target: "",
      source: "https://endeavor3d.com/designing-mjf-parts-with-inserts-threads-and-snap-fits/"
    },
    {
      tool: "Heat",
      method: "Apply localized heat",
      target: "Components",
      source: "https://next.henkel-adhesives.com/us/en/products/industrial-adhesives/central-pdp.html/loctite-680/BP000000153464.html"
    },
    {
      tool: "Force",
      method: "Apply force",
      target: "Components",
      source: "https://next.henkel-adhesives.com/us/en/products/industrial-adhesives/central-pdp.html/loctite-680/BP000000153464.html"
    },
    {
      tool: "Ejector pin pullers",
      method: "Pull",
      target: "Ejector pins",
      source: "https://firstmold.com/tips/injection-mold-repair/"
    },
    {
      tool: "Converts",
      method: "takes out",
      target: "plastic stop component",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Converts",
      method: "takes out",
      target: "plastic stop component",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Presses",
      method: "pushes",
      target: "parts",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "The 6 disassembly rods",
      method: "handle",
      target: "nearly all tube diameters and parts configurations",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Disassembly press",
      method: "Presses out parts with 7mm mechanisms",
      target: "Plastic stop component",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Disassembly press",
      method: "Takes out plastic stop component",
      target: "",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Dedicated disassembly bushing",
      method: "disassembles",
      target: "7mm mechanisms",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Soft grip tube and V profile clamp",
      method: "protects",
      target: "parts",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Sanitary type can opener",
      method: "Cut out the centre section of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Tin snips",
      method: "Cut out the centre section of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Nippers",
      method: "Remove the remainder of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Dremel",
      method: "Remove screw",
      target: "Evap fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Dremel",
      method: "Remove screw",
      target: "Back panel",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Screwdriver",
      method: "Stripped",
      target: "Screw",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Built",
      method: "in oil rail drain",
      target: "Draining oil from compressor during disassembly",
      source: "https://screwcompressorsspecialist.com/"
    },
    {
      tool: "Dremel",
      method: "Remove screw",
      target: "Evap fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Wet vac",
      method: "Empty water from",
      target: "Drain",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "ProMAXX Tool",
      method: "Tighten the flange",
      target: "Fuel injector passage",
      source: "https://miltonindustries.com/products/power-stroke-powerpac-ford-67-bolt-repair-fuel-injector-puller-combo-xsz7k"
    },
    {
      tool: "ProMAXX Tool",
      method: "Machine the old fastener out",
      target: "Old fastener",
      source: "https://miltonindustries.com/products/power-stroke-powerpac-ford-67-bolt-repair-fuel-injector-puller-combo-xsz7k"
    },
    {
      tool: "6",
      method: "point wrench or socket",
      target: "[method] \u2013 [COMPONENT]",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "6",
      method: "point socket/wrench",
      target: "[ROCK] \u2013 [BOLT]",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "6",
      method: "point socket/wrench",
      target: "[ROCK] \u2013 [BOLT]",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Propane torch",
      method: "Heat",
      target: "Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Propane torch",
      method: "Remove heat",
      target: "Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Propane torch",
      method: "Pour warm water on",
      target: "Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Breaker bar",
      method: "Turn",
      target: "Bolt",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut Splitter",
      method: "Slipped over seized nut",
      target: "Seized Nut",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Nut Splitter",
      method: "Screw tightened",
      target: "Nut Splitter",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Angle grinder",
      method: "CUT OFF HEAD",
      target: "BOLT",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Angle grinder",
      method: "GRIND NUT AND BOLT",
      target: "NUT",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Wire brush",
      method: "CLEAN",
      target: "Hex portion",
      source: "https://www.instructables.com/How-to-remove-a-stuborn-nutbolt/"
    },
    {
      tool: "Dremel",
      method: "Remove screw",
      target: "Evap fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Spanner wrench",
      method: "remove nut",
      target: "threaded antenna shaft",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Pliers",
      method: "twist counter",
      target: "clockwise \u2013 silver nut",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Small flat",
      method: "head screwdriver",
      target: "pry bottom of chassis \u2013 plastic housing",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Pliers",
      method: "catch indents",
      target: "silver nut",
      source: "https://www.twowayradioforum.com/t/icom-ic-f3001f4001-radio-disassembly-and-review/5910"
    },
    {
      tool: "Dremel",
      method: "Remove Screw",
      target: "Evap Fan",
      source: "https://www.reddit.com/r/Appliances/comments/188czyo/most_appliance_repair_companies_dont_ever_fix/"
    },
    {
      tool: "Adhesive adjustable aluminum clamp",
      method: "Remove nut",
      target: "Adhesive adjustable cable clamp",
      source: "https://www.isc-sl.com/releasable-snap-rivet-bevelled-head/mrmhv/"
    },
    {
      tool: "Cable tie",
      method: "Release tension",
      target: "Cable tie flat head",
      source: "https://www.isc-sl.com/releasable-snap-rivet-bevelled-head/mrmhv/"
    },
    {
      tool: "Cable tie mount",
      method: "Remove mounting clip",
      target: "Cable tie with fin clip base",
      source: "https://www.isc-sl.com/releasable-snap-rivet-bevelled-head/mrmhv/"
    },
    {
      tool: "Cable tie with screw fixing system not reusable",
      method: "Break lock",
      target: "Cable tie with threaded fastening to fix",
      source: "https://www.isc-sl.com/releasable-snap-rivet-bevelled-head/mrmhv/"
    },
    {
      tool: "Hammer",
      method: "Struck",
      target: "Projection",
      source: "https://www.premiumparts.com/blog/an-ultimate-guide-to-rivet-their-types-and-applications"
    },
    {
      tool: "Hammer",
      method: "Formed",
      target: "End",
      source: "https://www.premiumparts.com/blog/an-ultimate-guide-to-rivet-their-types-and-applications"
    },
    {
      tool: "Use normal tools",
      method: "break free",
      target: "bolt",
      source: "https://permabond.com/remove-industrial-adhesive/"
    },
    {
      tool: "Use a metal brush",
      method: "thoroughly remove adhesive (pipe sealant)",
      target: "pipe",
      source: "https://permabond.com/remove-industrial-adhesive/"
    },
    {
      tool: "Scrape the gasket",
      method: "",
      target: "form in place gasket",
      source: "https://permabond.com/remove-industrial-adhesive/"
    },
    {
      tool: "Metal Spatula",
      method: "[GENTLY]",
      target: "Soft Excess",
      source: "https://permabond.com/remove-industrial-adhesive/"
    },
    {
      tool: "Paper Towel",
      method: "[WIPING]",
      target: "Joint",
      source: "https://permabond.com/remove-industrial-adhesive/"
    },
    {
      tool: "CUTTER",
      method: "CUT OFF",
      target: "ADHESIVE STRIP",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Screwdriver",
      method: "Remove",
      target: "Screws",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Screwdriver",
      method: "Remove",
      target: "Screws",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "Screwdriver",
      method: "Remove",
      target: "Screws",
      source: "https://gtg.benabraham.net/what-i-learned-about-repair-by-disassembling-my-imac/"
    },
    {
      tool: "1000# sandpaper",
      method: "removal",
      target: "burr",
      source: "https://cjme.springeropen.com/articles/10.1186/s10033-023-00885-7"
    },
    {
      tool: "Mechanical press",
      method: "Apply force",
      target: "Press",
      source: "https://www.hlc-metalparts.com/news/press-fit-a-comprehensive-guide-80325696.html"
    },
    {
      tool: "Hot press",
      method: "Heat/cool shaft parts",
      target: "Shrink",
      source: "https://www.hlc-metalparts.com/news/press-fit-a-comprehensive-guide-80325696.html"
    },
    {
      tool: "Disassembly tool module",
      method: "[method]",
      target: "snap-fit cover",
      source: "https://link.springer.com/article/10.1007/s00170-013-5174-8"
    },
    {
      tool: "Disassembly tool module",
      method: "[method]",
      target: "batteries",
      source: "https://link.springer.com/article/10.1007/s00170-013-5174-8"
    },
    {
      tool: "Ejector pin pullers",
      method: "[ method ]",
      target: "ejector pins",
      source: "https://firstmold.com/tips/injection-mold-repair/"
    },
    {
      tool: "Installation tools",
      method: "[ method ]",
      target: "ejector system",
      source: "https://firstmold.com/tips/injection-mold-repair/"
    },
    {
      tool: "Hammers",
      method: "[ method ]",
      target: "parts with burrs or sharp edges",
      source: "https://firstmold.com/tips/injection-mold-repair/"
    },
    {
      tool: "Convert",
      method: "Remove",
      target: "Plastic stop component",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Presses out",
      method: "Parts",
      target: "[No specific component mentioned]",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Pushes",
      method: "Parts",
      target: "[No specific component mentioned]",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Plastic stop component",
      method: "Taken out",
      target: "",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Locking lever",
      method: "Loosened",
      target: "Rod",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Converts",
      method: "takes out",
      target: "plastic stop component",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Presses",
      method: "presses out",
      target: "parts",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "The 6 disassembly rods",
      method: "pushes",
      target: "parts out the pen tube",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "[DISASSEMBLY BUSHING]",
      method: "Lets you disassemble",
      target: "7mm pen",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "[DISASSEMBLY BUSHING]",
      method: "Lets you disassemble",
      target: "7mm pen",
      source: "https://www.pennstateind.com/store/PENPRESSXL.html"
    },
    {
      tool: "Load",
      method: "Apply vertically",
      target: "Base plate",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Seaming chuck",
      method: "Clamp on",
      target: "Can body",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Tucks",
      method: "The end curl under",
      target: "Can flange",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Sanitary type can opener",
      method: "Cut out the centre section of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Tin snips",
      method: "Cut out the centre section of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    },
    {
      tool: "Nippers",
      method: "Remove the remainder of the can end",
      target: "Can end",
      source: "http://inspection.canada.ca/en/preventive-controls/controls-food/metal-can-defects"
    }
  ]

  const handleSearch = () => {
    const results = partsData.filter(part =>
      part.tool.toLowerCase() === searchTerm.toLowerCase()
    )
    setAllResults(results)
    setSearchResult(null)
  }

  const handleShowAll = () => {
    setAllResults(partsData)
    setSearchResult(null)
  }

  const handleClear = () => {
    setSearchTerm('')
    setSearchResult(null)
    setAllResults([])
  }

  const handleSendMessage = () => {
    if (!prompt.trim()) return

    // Add user message to chat history
    setChatHistory(prev => [...prev, { role: 'user', content: prompt }])
    // Simulate AI response (replace with actual API call)
    setChatHistory(prev => [...prev, { role: 'assistant', content: 'This is a simulated AI response. In a real application, this would be replaced with an actual AI API call.' }])
    setPrompt('')
  }

  return (
    <div className="app-container">
      <nav className="nav-bar">
        <div
          className={`nav-item ${activeTab === 'parts' ? 'active' : ''}`}
          onClick={() => setActiveTab('parts')}
        >
          Parts Search
        </div>
        <div
          className={`nav-item ${activeTab === 'chat' ? 'active' : ''}`}
          onClick={() => setActiveTab('chat')}
        >
          Ask LLM
        </div>
        <div
          className={`nav-item ${activeTab === 'reference' ? 'active' : ''}`}
          onClick={() => setActiveTab('reference')}
        >
          Reference
        </div>
      </nav>

      {activeTab === 'parts' ? (
        <div className="container">
          <h1>Parts Disassembly Search System</h1>
          <div className="description">
            Search for tools and their disassembly methods
          </div>
          <div className="search-box">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Enter tool name"
            />
            <button onClick={handleSearch}>Search</button>
            <button onClick={handleClear}>Clear</button>
            <button onClick={handleShowAll}>Show All</button>
          </div>
          {searchResult && (
            <div className="result">
              {`${searchResult.tool} - ${searchResult.method} - ${searchResult.target}`}
            </div>
          )}
          {allResults.length > 0 && (
            <div className="results-list">
              {allResults.map((result, index) => (
                <div key={index} className="result">
                  {`${result.tool} - ${result.method} - ${result.target}`}
                </div>
              ))}
            </div>
          )}
          <div className="user-guide">
            <p>User Guide: Enter the tool name in the search box and click "Search" to find its disassembly method.</p>
            <p>Click "Show All" to display all available tools and their disassembly methods in the database.</p>
          </div>
        </div>
      ) : activeTab === 'chat' ? (
        <div className="chat-container">
          <div className="chat-header">
            <div className="chat-icon">AI</div>
            <div className="chat-welcome">What can I help you</div>
          </div>
          <div className="chat-history">
            {chatHistory.map((message, index) => (
              <div key={index} className={`chat-message ${message.role}`}>
                <div className="message-content">{message.content}</div>
              </div>
            ))}
          </div>
          <div className="chat-input-container">
            <div className="chat-input">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Input your questions here"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <button onClick={handleSendMessage}>Send</button>
            </div>
            <div className="chat-buttons">
              <button className="chat-button create-picture">Create a picture</button>
              <button className="chat-button help-write">Help me write</button>
              <button className="chat-button analyze-picture">Analyze the picture</button>
            </div>
          </div>
        </div>
      ) : (
        <div className="container">
          <h1>Reference Papers</h1>
          <div className="description">
            Click on the paper title to view the full article
          </div>
          <div className="reference-list">
            {references.map((ref, index) => (
              <div key={index} className="reference-item">
                <a href={ref.url} target="_blank" rel="noopener noreferrer">
                  {ref.title}
                </a>
                {index === 0 && (
                  <div className="reference-abstract">
                    The aim of the proposed model is to determine among several alternatives which one allows to meet the requirements in assembly, in-use, services and disassembly. The model takes into account the semi-destructive disassembly (deteriorate a part of a sub-assembly to recover valuable components or materials and while reducing the disassembly time without important value loss). The model developed in this paper is mainly based on the Analytic Network Process (ANP) to define the best alternative and make the fastener selection during the design process easily.
                  </div>
                )}
                {index === 1 && (
                  <div className="reference-abstract">
                    This research presents a robotic disassembly system aimed at addressing these issues. The system is tested on disassembly of various models of LCD screens with promising results, limited by sensing and model inaccuracies which were able to be resolved by user intervention. Specific product information obtained from user demonstration is supplemented with background knowledge relating actions to the fasteners to be disestablished. This goal-driven approach allows the substitution of dissimilar tools––namely a screwdriver, hole saw, and angle grinder––along with flexible reactive planning in the case of operation failures. A method of assessing and selecting desirable disassembly actions based on geometrical estimations of destructiveness is implemented. Finally, an improved method for the evaluation of systems employing (semi-) destructive disassembly is proposed.
                  </div>
                )}
                {index === 2 && (
                  <div className="reference-abstract">
                    This paper proposes a computer vision framework for detecting screws and recommending related tools for disassembly. First, a YOLOv4 algorithm is used to detect screw targets in EOL electronic devices and a screw image extraction mechanism is executed based on the position coordinates predicted by YOLOv4. Second, after obtaining the screw images, the EfficientNetv2 algorithm is applied for screw shape classification. In addition to proposing a framework for automatic small-object detection, we explore how to modify the object detection algorithm to improve its performance and discuss the sensitivity of tool recommendations to the detection predictions. A case study of three different types of screws in EOL electronics is used to evaluate the performance of the proposed framework.
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default App
